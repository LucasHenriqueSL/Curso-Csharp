﻿using System;
using System.Collections.Generic;
using System.Text;

namespace tabuleiro
{
    enum Cor
    {
        Branca,
        Preta,
        Amarela,
        Azul,
        Vermelha,
        Verde,
        Laranja
    }
}
